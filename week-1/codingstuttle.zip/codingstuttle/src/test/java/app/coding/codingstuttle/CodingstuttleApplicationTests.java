package app.coding.codingstuttle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingstuttleApplicationTests {

	@Test
	void contextLoads() {
	}

}
